# Fleet Inventory — Brand Assets

The mark is a **rack of systems**: four horizontal blade bars in a rounded square,
with the third bar highlighted in bright teal (the "selected machine") to echo the
dashboard's row-selection interaction. Status LED dots sit on each bar.

## Palette

| Role            | Hex       | Use |
|-----------------|-----------|-----|
| Canvas          | `#0b0e14` | page background, theme-color |
| Panel           | `#121722` | icon body, cards |
| Border          | `#232c3d` | hairlines, icon stroke |
| Text primary    | `#d6deec` | wordmark "Fleet" |
| Muted           | `#7d8aa3` | "INVENTORY" subtitle |
| Accent (teal)   | `#36d0c4` | selected bar, LEDs, the "." |
| Accent dim      | `#1c6f69` | inactive bars |
| Accent (light)  | `#1aa79b` | teal for use on white backgrounds |

Wordmark typeface: monospace (ui-monospace / SF Mono / JetBrains Mono / Menlo).
"Fleet" in primary with a teal period; "INVENTORY" letter-spaced muted below.

## Files

| File | Purpose |
|------|---------|
| `icon-dark.svg` | master icon, 256px, dark |
| `icon-light.svg` | icon for white/light backgrounds (decks, finance docs) |
| `favicon.svg` | simplified mark (bars survive 16px), browser favicon |
| `favicon.ico` | multi-res 16/32/48 ICO fallback |
| `favicon-{16,32,48}.png` | PNG favicon fallbacks |
| `icon-{16,32,180,192,512}.png` | app tile / PWA / apple-touch icons |
| `lockup-dark.svg` / `.png` | horizontal icon + wordmark, dark |
| `lockup-light.svg` / `.png` | horizontal lockup for light backgrounds |
| `og-card.svg` / `.png` | 1200×630 social/share card |
| `manifest.webmanifest` | PWA manifest (lives in `api/static/`) |

## Already wired up

The web-facing assets (`favicon.svg`, `favicon.ico`, `icon-180/192/512.png`,
`og-card.png`, `manifest.webmanifest`) are copied into `api/static/` and referenced
from `index.html`. The header uses an inline copy of the icon SVG. The Replit build
prompt embeds the icon SVG so a Replit build reproduces it exactly.

## Clear space & sizing

Keep padding of at least one bar-height around the icon. Don't recolor the bars
outside the palette above, don't add gradients or shadows (flat only), and don't
stretch the lockup — scale proportionally.
